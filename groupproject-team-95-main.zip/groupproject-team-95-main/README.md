# Battle Of The Marauders

This is a 16-bit RPG video game made in Python and Pygame in a team of four developers (Vivek Jariwala, Jeffano John, Aahash Srikumar, and Ahmed Elghandour). Within the game's story, players of the video game have been trapped inside it. TO escape, they must vanquish all the other enemies and traverse the terrains of the world to escape. During the game, players will engage in 2D platforming, turn-based combat, and can even upgrade their character's abilities.

Access the gameplay demo here: https://youtu.be/qAzOMhzLd8Q
